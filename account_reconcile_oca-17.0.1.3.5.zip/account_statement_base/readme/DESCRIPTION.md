This is a technical module that adds the views of the **Bank Statement
Lines** (since Odoo 16.0, these views are not part of the *account*
module any more).
